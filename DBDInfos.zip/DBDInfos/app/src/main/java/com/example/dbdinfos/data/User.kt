package com.example.dbdinfos.data

data class User (
    val email: String = "",
    val password: String = ""
        )